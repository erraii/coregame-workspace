# Local evolution run report

Status: paused. Stop: Wall budget reserve reached.

Champion: 13ae14da4b8d3c0a13a5a77559155700dfeccace17e16939ad787f0d7eb3db38

Completed committed games: 1264; reserved slots: 1264; finalized candidates: 30; evaluated: 25; skipped: 5; promotions: 2.

Rejections/outcomes: {"validation rejection":15,"ineffective/dependency skip":5,"promoted":2,"training rejection":8}. Pending: f0612c89fc845031c74532e8bece44acb6f66afeb4b0f40e6e1cb67f2a7e5b84.

Failures: {}; errors: [{"at":"2026-10-24T14:48:19.435Z","message":"Wall budget reserve reached"},{"at":"2026-10-24T15:53:31.810Z","message":"Wall budget reserve reached"}].

| Iteration | Changes from parent | Result | Train delta | Validation delta |
|---|---|---|---:|---:|
| 0 | guard_radius: 12 → 11 | validation rejection: paired regressions, opponent-average regression | 0.125 | 0.078125 |
| 1 | guards: 2 → 3, defense_gain: 1 → 2 | validation rejection: delta below 0.05, paired regressions | 0.15625 | 0.03125 |
| 2 | target_bias: 2 → 1 | ineffective/dependency skip | — | — |
| 3 | defense_gain: 2 → 1 | promoted | 0.25 | 0.109375 |
| 4 | return_load: 35 → 20 | training rejection | 0 | — |
| 5 | attack_commit: 0 → 1 | ineffective/dependency skip | — | — |
| 6 | carriers: 0 → 1, carrier_load: 35 → 50 | validation rejection: paired regressions | 0.08333333333333337 | 0.25 |
| 7 | carriers: 0 → 1 | validation rejection: paired regressions | 0.35416666666666663 | 0.20000000000000007 |
| 8 | miners: 2 → 1 | validation rejection: paired regressions | 0.31250000000000006 | 0.15000000000000002 |
| 9 | carriers: 0 → 1, carrier_load: 35 → 50 | validation rejection: paired regressions | 0.33333333333333326 | 0.22499999999999998 |
| 10 | carriers: 0 → 1 | validation rejection: paired regressions, opponent-average regression | 0.22916666666666663 | 0.11249999999999993 |
| 11 | return_load: 35 → 50 | validation rejection: paired regressions | 0.39583333333333326 | 0.125 |
| 12 | threat_radius: 12 → 13 | validation rejection: paired regressions | 0.4583333333333333 | 0.2749999999999999 |
| 13 | carriers: 0 → 1 | validation rejection: paired regressions | 0.3333333333333333 | 0.15000000000000002 |
| 14 | carrier_load: 35 → 20 | ineffective/dependency skip: carrier_load inactive: candidate cannot produce own carriers and worlds start without units | — | — |
| 15 | miners: 2 → 3 | validation rejection: paired regressions | 0.08333333333333331 | 0.09999999999999998 |
| 16 | carrier_load: 35 → 20 | ineffective/dependency skip: carrier_load inactive: candidate cannot produce own carriers and worlds start without units | — | — |
| 17 | economy_end: 400 → 500 | training rejection | 0 | — |
| 18 | late_miners: 1 → 2 | training rejection | 0 | — |
| 19 | attacker_design: 1 → 0 | validation rejection: delta below 0.05, fewer than two paired gains, paired regressions, opponent-average regression | 0.06250000000000006 | -0.04999999999999993 |
| 20 | carrier_load: 35 → 20 | ineffective/dependency skip: carrier_load inactive: candidate cannot produce own carriers and worlds start without units | — | — |
| 21 | attacker_design: 1 → 0 | training rejection | -0.062499999999999944 | — |
| 22 | avoid_weight: 16 → 8 | validation rejection: delta below 0.05, paired regressions, opponent-average regression | 0.10416666666666674 | 0.012499999999999956 |
| 23 | avoid_weight: 16 → 24 | validation rejection: delta below 0.05, paired regressions, opponent-average regression | 0.0625 | -0.012499999999999956 |
| 24 | threat_radius: 12 → 11 | training rejection | -0.08333333333333337 | — |
| 25 | defense_gain: 1 → 2 | validation rejection: paired regressions | 0.2708333333333333 | 0.08749999999999991 |
| 26 | carriers: 0 → 1, carrier_load: 35 → 50 | promoted | 0.16666666666666663 | 0.20000000000000007 |
| 27 | late_miners: 1 → 0 | training rejection | -0.296875 | — |
| 28 | avoid_weight: 16 → 24 | training rejection | -0.015625 | — |
| 29 | miners: 2 → 1, economy_end: 400 → 500 | training rejection | -0.109375 | — |

Per-opponent outcomes (all committed panels, including incumbent controls):

| Opponent | Games | Wins | Losses | Combat | HP | Random |
|---|---:|---:|---:|---:|---:|---:|
| tactical-baseline | 340 | 128 | 212 | 216 | 124 | 0 |
| initial-evolution | 336 | 248 | 88 | 171 | 164 | 1 |
| Gridmaster | 136 | 136 | 0 | 136 | 0 | 0 |
| linear-policy | 136 | 136 | 0 | 136 | 0 | 0 |
| candidate-3 | 288 | 183 | 105 | 100 | 188 | 0 |
| candidate-9 | 28 | 11 | 17 | 13 | 15 | 0 |
