# Local evolution run report

Status: paused. Stop: Invocation match budget reached.

Champion: 661916b9726df597b051428ed1e5489375dd69a1b8ba20687dfc95766fecd840

Completed committed games: 0; reserved slots: 0; finalized candidates: 0; evaluated: 0; skipped: 0; promotions: 0.

Rejections/outcomes: {}. Pending: 23095375345119aacac5e8ee71b4a0032958925e6f26a74754e4b0b58aa61373.

Failures: {}; errors: [{"at":"2026-10-24T17:01:37.084Z","message":"Invocation match budget reached"}].

| Iteration | Changes from parent | Result | Train delta | Validation delta |
|---|---|---|---:|---:|

Per-opponent outcomes (all committed panels, including incumbent controls):

| Opponent | Games | Wins | Losses | Combat | HP | Random |
|---|---:|---:|---:|---:|---:|---:|
