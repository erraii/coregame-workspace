# Local evolution run report

Status: idle. Stop: Pending candidate resolved.

Champion: e539c7dc8871fff608df8e7316c53b2d4f922456037956d3a7c6f0b23fbeb4bc

Completed committed games: 48; reserved slots: 50; finalized candidates: 1; evaluated: 1; skipped: 0; promotions: 0.

Rejections/outcomes: {"validation rejection":1}. Pending: none.

Failures: {}; errors: [{"at":"2026-10-24T12:40:18.799Z","message":"Server exited before Server listening on port 4444"}].

| Iteration | Changes from parent | Result | Train delta | Validation delta |
|---|---|---|---:|---:|
| 0 | guard_radius: 12 → 11 | validation rejection: delta below 0.05, fewer than two paired gains, paired regressions, opponent-average regression | 0.0625 | -0.0625 |

Per-opponent outcomes (all committed panels, including incumbent controls):

| Opponent | Games | Wins | Losses | Combat | HP | Random |
|---|---:|---:|---:|---:|---:|---:|
| tactical-baseline | 16 | 2 | 14 | 0 | 16 | 0 |
| initial-evolution | 16 | 7 | 9 | 0 | 16 | 0 |
| Gridmaster | 8 | 8 | 0 | 8 | 0 | 0 |
| linear-policy | 8 | 8 | 0 | 8 | 0 | 0 |
