#ifndef CORE_LIB_INTERNAL_H
#define CORE_LIB_INTERNAL_H

#include "core_lib.h"

// ----- General

int core_internal_distance(t_pos pos1, t_pos pos2);
bool core_internal_isPosValid(t_pos pos);
void core_internal_freeStringArray(char **array);
void core_internal_freeObject(t_obj *obj);
void core_internal_freeObjects(void);
void core_internal_objPositionIndex_rebuild(void);
void core_internal_objPositionIndex_free(void);
void core_internal_travelWorkspace_free(void);
void core_internal_freeAndExit(const char *msg, int count, ...);

// ----- Socket

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netdb.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <unistd.h>

int core_internal_socket_init(struct sockaddr_in addr);
int core_internal_socket_send(int socket_fd, const char *msg);
char *core_internal_socket_read(int socket_fd);
char *core_internal_socket_read_once(int socket_fd);
struct sockaddr_in core_internal_socket_initAddr(const char *hostname, int port);

// ----- Actions

typedef enum e_action_type
{
	ACTION_CREATE,
	ACTION_MOVE,
	ACTION_ATTACK,
	ACTION_TRANSFER
} t_action_type;

typedef struct s_action
{
	t_action_type type;
	union
	{
		struct
		{
			char *name;
			char **components;
		} create;
		struct
		{
			unsigned long id;
			t_pos pos;
		} move;
		struct
		{
			unsigned long id;
			unsigned long target_id;
		} attack;
		struct
		{
			unsigned long source_id;
			t_pos target_pos;
			unsigned long amount;
		} transfer;
	} data;
} t_action;

typedef struct s_actions
{
	t_action *list;
	unsigned int count;
	unsigned int capacity;
} t_actions;

extern t_actions actions;

void core_internal_reset_actions(void);

// ----- Debug Data

typedef struct s_debug_path_node
{
	t_pos pos;
	struct s_debug_path_node *next;
} t_debug_path_node;

typedef struct s_debug_entry
{
	unsigned long object_id;
	char *info; // Accumulated info string for this object
	t_debug_path_node *path;
} t_debug_entry;

typedef struct s_debug_data
{
	t_debug_entry *entries;
	unsigned int count;
	unsigned int capacity;
} t_debug_data;

extern t_debug_data debug_data;

void core_internal_reset_debugData(void);

// ----- JSON LIB

#include <ctype.h>

typedef enum e_json_type
{
	JSON_TYPE_NULL,
	JSON_TYPE_BOOL,
	JSON_TYPE_STRING,
	JSON_TYPE_NUMBER,
	JSON_TYPE_OBJECT,
	JSON_TYPE_ARRAY
} json_type;

typedef struct s_json_node
{
	char *key;
	json_type type;

	union
	{
		char *string;
		double number;
		struct s_json_node **array;
	};
} json_node;

json_node *string_to_json(char *string);					// Convert a JSON string into a JSON tree
char *json_to_string(json_node *json);						// Convert a JSON tree to a JSON string
char *json_to_formatted_string(json_node *json);			// Convert a JSON tree to a formatted JSON string
json_node *json_find(json_node *json, char *key);			// Find a node in the JSON tree by key (top-level only)
json_node *json_find_recursive(json_node *json, char *key); // Find a node in the JSON tree by key (recursive)
void free_json(json_node *json);							// Free all memory allocated for the JSON tree
json_node *create_node(json_type type);						// Create a new, empty-initialized node

// ----- JSON parsing and encoding

unsigned long clamp_ulong_for_json(unsigned long value);

void core_internal_parse_state(char *json);

char *core_internal_encode_login(const char *team_name, int argc, char **argv);

json_node *core_internal_encode_packet_actions(void);
json_node *core_internal_encode_packet_debugData(void);
char *core_internal_encode_packet(void);

#endif // CORE_LIB_INTERNAL_H
